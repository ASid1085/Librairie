package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class LigneCommande implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, length = 4, nullable = false, unique = false, updatable = true)
    private java.lang.Integer quantite;
    @javax.persistence.Column(insertable = true, length = 10, nullable = false, precision = 2, unique = false, updatable = true)
    private java.lang.Float prixHT;
    
    private java.lang.Float remise;
    @javax.persistence.Column(insertable = true, length = 4, nullable = false, precision = 2, unique = false, updatable = true)
    private java.lang.Float tvaAppliquee;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "evenement_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "ligCommande_evenement_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Evenement evenement;
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "livreCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "ligCommande_Livre_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Livre livreCommande;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setQuantite(java.lang.Integer quantite) {
        this.quantite = quantite;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getQuantite() {
        return this.quantite;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrixHT(java.lang.Float prixHT) {
        this.prixHT = prixHT;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getPrixHT() {
        return this.prixHT;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRemise(java.lang.Float remise) {
        this.remise = remise;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getRemise() {
        return this.remise;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTvaAppliquee(java.lang.Float tvaAppliquee) {
        this.tvaAppliquee = tvaAppliquee;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getTvaAppliquee() {
        return this.tvaAppliquee;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setEvenement(Evenement evenement) {
        this.evenement = evenement;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Evenement getEvenement() {
        return this.evenement;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setLivreCommande(Livre livreCommande) {
        this.livreCommande = livreCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Livre getLivreCommande() {
        return this.livreCommande;
    }
    
}

