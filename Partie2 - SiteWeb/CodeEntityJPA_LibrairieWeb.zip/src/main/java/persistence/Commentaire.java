package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Commentaire implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, length = 500, nullable = false, unique = false, updatable = true)
    private java.lang.String texte;
    @javax.persistence.Column(insertable = true, length = 20, nullable = false, unique = false, updatable = true)
    private java.lang.String note;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String ip;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    LigneCommande laisserCommentaire;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "ListStatutCommentaire_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "commentaire_statutCommentaire_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<StatutCommentaire> ListStatutCommentaire;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTexte(java.lang.String texte) {
        this.texte = texte;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getTexte() {
        return this.texte;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNote(java.lang.String note) {
        this.note = note;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNote() {
        return this.note;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setIp(java.lang.String ip) {
        this.ip = ip;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getIp() {
        return this.ip;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setLaisserCommentaire(LigneCommande laisserCommentaire) {
        this.laisserCommentaire = laisserCommentaire;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public LigneCommande getLaisserCommentaire() {
        return this.laisserCommentaire;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListStatutCommentaire(java.util.Collection<StatutCommentaire> ListStatutCommentaire) {
        this.ListStatutCommentaire = ListStatutCommentaire;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<StatutCommentaire> getListStatutCommentaire() {
        return this.ListStatutCommentaire;
    }
    
}

