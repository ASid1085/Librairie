package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Evenement implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    
    private java.lang.String nom;
    
    private java.util.Date dateDebut;
    
    private java.util.Date dateFin;
    @javax.persistence.Column(insertable = true, length = 4, nullable = true, precision = 2, unique = false, updatable = true)
    private java.lang.Float pourcentage;
    
    private java.lang.String codePromo;
    
    private java.lang.String image;
    
    private java.lang.String blabla;
    

    

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNom(java.lang.String nom) {
        this.nom = nom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNom() {
        return this.nom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDateDebut(java.util.Date dateDebut) {
        this.dateDebut = dateDebut;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDateDebut() {
        return this.dateDebut;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDateFin(java.util.Date dateFin) {
        this.dateFin = dateFin;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDateFin() {
        return this.dateFin;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPourcentage(java.lang.Float pourcentage) {
        this.pourcentage = pourcentage;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getPourcentage() {
        return this.pourcentage;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setCodePromo(java.lang.String codePromo) {
        this.codePromo = codePromo;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getCodePromo() {
        return this.codePromo;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setImage(java.lang.String image) {
        this.image = image;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getImage() {
        return this.image;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    

    
}

