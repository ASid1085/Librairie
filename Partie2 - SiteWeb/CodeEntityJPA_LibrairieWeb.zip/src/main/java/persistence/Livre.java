package persistence;

@javax.persistence.Table(
    
)
@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Livre implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(name = "ISBN", insertable = true, length = 12, nullable = false, table = "Livre", unique = true, updatable = true)
    private java.lang.String isbn;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String titre;
    
    private java.lang.String sousTitre;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.Float prixHT;
    
    private java.lang.String image;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String resume;
    @javax.persistence.Column(insertable = true, length = 8, nullable = false, unique = false, updatable = true)
    private java.lang.Integer nbrePage;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.Integer stock;
    
    private java.lang.String dateEdition;
    
    private java.lang.String blabla;
    
    private java.lang.String statut;
    

    
    @javax.persistence.ManyToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        name="livre_motCle",
    	joinColumns={@javax.persistence.JoinColumn(
    name = "ListMotCle_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "livre_mc_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    },
    	inverseJoinColumns={@javax.persistence.JoinColumn(
    name = "motCle_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true
    )
    }
    )
    java.util.Collection<MotCle> ListMotCle;
    @javax.persistence.ManyToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        name="livre_theme",
    	joinColumns={@javax.persistence.JoinColumn(
    name = "ListTheme_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "livre_theme_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    },
    	inverseJoinColumns={@javax.persistence.JoinColumn(
    name = "theme_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true
    )
    }
    )
    java.util.Collection<Theme> ListTheme;
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "tvaLivre_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "livre_tva_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Tva tvaLivre;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "CommentairesDuLivre_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "livre_Commentaire_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Commentaire> commentairesDuLivre;
    @javax.persistence.ManyToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        name="livre_Auteur",
    	joinColumns={@javax.persistence.JoinColumn(
    name = "ListAuteur_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "Livre_Auteur_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    },
    	inverseJoinColumns={@javax.persistence.JoinColumn(
    name = "auteur_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true
    )
    }
    )
    java.util.Collection<Auteur> ListAuteur;
    @javax.persistence.ManyToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "editeur_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "livre_editeur_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Editeur editeur;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setIsbn(java.lang.String isbn) {
        this.isbn = isbn;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getIsbn() {
        return this.isbn;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTitre(java.lang.String titre) {
        this.titre = titre;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getTitre() {
        return this.titre;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setSousTitre(java.lang.String sousTitre) {
        this.sousTitre = sousTitre;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getSousTitre() {
        return this.sousTitre;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrixHT(java.lang.Float prixHT) {
        this.prixHT = prixHT;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getPrixHT() {
        return this.prixHT;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setImage(java.lang.String image) {
        this.image = image;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getImage() {
        return this.image;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setResume(java.lang.String resume) {
        this.resume = resume;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getResume() {
        return this.resume;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNbrePage(java.lang.Integer nbrePage) {
        this.nbrePage = nbrePage;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getNbrePage() {
        return this.nbrePage;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setStock(java.lang.Integer stock) {
        this.stock = stock;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getStock() {
        return this.stock;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDateEdition(java.lang.String dateEdition) {
        this.dateEdition = dateEdition;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getDateEdition() {
        return this.dateEdition;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setStatut(java.lang.String statut) {
        this.statut = statut;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getStatut() {
        return this.statut;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListMotCle(java.util.Collection<MotCle> ListMotCle) {
        this.ListMotCle = ListMotCle;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<MotCle> getListMotCle() {
        return this.ListMotCle;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListTheme(java.util.Collection<Theme> ListTheme) {
        this.ListTheme = ListTheme;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Theme> getListTheme() {
        return this.ListTheme;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setTvaLivre(Tva tvaLivre) {
        this.tvaLivre = tvaLivre;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Tva getTvaLivre() {
        return this.tvaLivre;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setCommentairesDuLivre(java.util.Collection<Commentaire> commentairesDuLivre) {
        this.commentairesDuLivre = commentairesDuLivre;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Commentaire> getCommentairesDuLivre() {
        return this.commentairesDuLivre;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListAuteur(java.util.Collection<Auteur> ListAuteur) {
        this.ListAuteur = ListAuteur;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Auteur> getListAuteur() {
        return this.ListAuteur;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setEditeur(Editeur editeur) {
        this.editeur = editeur;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Editeur getEditeur() {
        return this.editeur;
    }
    
}

