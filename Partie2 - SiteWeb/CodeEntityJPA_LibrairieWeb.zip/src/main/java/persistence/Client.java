package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Client implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.String login;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String mdp;
    @javax.persistence.Column(insertable = true, length = 15, nullable = false, unique = false, updatable = true)
    private java.lang.String civilite;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.String email;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String nom;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String prenom;
    @javax.persistence.Column(insertable = true, length = 20, nullable = true, unique = false, updatable = true)
    private java.lang.String tel;
    @javax.persistence.Column(insertable = true, length = 300, nullable = true, unique = false, updatable = true)
    private java.lang.String blabla;
    
    private java.lang.String statut;
    

    
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "commentairePoste_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "client_Commentaire_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Commentaire> commentairePoste;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "adressesClient_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "client_adresse_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Adresse> adressesClient;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "ListCommandeClient_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "client_Commande_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Commande> ListCommandeClient;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setLogin(java.lang.String login) {
        this.login = login;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getLogin() {
        return this.login;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setMdp(java.lang.String mdp) {
        this.mdp = mdp;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getMdp() {
        return this.mdp;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setCivilite(java.lang.String civilite) {
        this.civilite = civilite;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getCivilite() {
        return this.civilite;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setEmail(java.lang.String email) {
        this.email = email;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getEmail() {
        return this.email;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNom(java.lang.String nom) {
        this.nom = nom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNom() {
        return this.nom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrenom(java.lang.String prenom) {
        this.prenom = prenom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getPrenom() {
        return this.prenom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTel(java.lang.String tel) {
        this.tel = tel;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getTel() {
        return this.tel;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setStatut(java.lang.String statut) {
        this.statut = statut;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getStatut() {
        return this.statut;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setCommentairePoste(java.util.Collection<Commentaire> commentairePoste) {
        this.commentairePoste = commentairePoste;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Commentaire> getCommentairePoste() {
        return this.commentairePoste;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setAdressesClient(java.util.Collection<Adresse> adressesClient) {
        this.adressesClient = adressesClient;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Adresse> getAdressesClient() {
        return this.adressesClient;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListCommandeClient(java.util.Collection<Commande> ListCommandeClient) {
        this.ListCommandeClient = ListCommandeClient;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Commande> getListCommandeClient() {
        return this.ListCommandeClient;
    }
    
}

