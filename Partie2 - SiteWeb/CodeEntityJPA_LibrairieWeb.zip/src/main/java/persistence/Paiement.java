package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Paiement implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    @javax.persistence.GeneratedValue
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String moyenPaiement;
    

    

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setMoyenPaiement(java.lang.String moyenPaiement) {
        this.moyenPaiement = moyenPaiement;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getMoyenPaiement() {
        return this.moyenPaiement;
    }
    

    
}

