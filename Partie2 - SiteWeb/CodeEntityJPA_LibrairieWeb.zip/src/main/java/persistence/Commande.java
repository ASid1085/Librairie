package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Commande implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String numCommande;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.String numFacture;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.Float forfaitLivraison;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.util.Date date;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.String ip;
    
    private java.lang.String blabla;
    @javax.persistence.Column(insertable = true, length = 4, nullable = false, precision = 2, unique = false, updatable = true)
    private java.lang.Float tvaLivraison;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "adr_facture_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "cde_adrFacture_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Adresse adresseFact;
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "adr_livraison_pk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "cde_adrLivraison_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Adresse adresseLiv;
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "paiement_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "cde_paiement_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Paiement paiement;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "tvaCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "Commande_tva_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Tva> tvaCommande;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "detailCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "commande_LigCommande_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<LigneCommande> detailCommande;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "ListCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "commande_statutCommande_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<StatutCommande> ListCommande;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNumCommande(java.lang.String numCommande) {
        this.numCommande = numCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNumCommande() {
        return this.numCommande;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNumFacture(java.lang.String numFacture) {
        this.numFacture = numFacture;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNumFacture() {
        return this.numFacture;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setForfaitLivraison(java.lang.Float forfaitLivraison) {
        this.forfaitLivraison = forfaitLivraison;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getForfaitLivraison() {
        return this.forfaitLivraison;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDate(java.util.Date date) {
        this.date = date;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDate() {
        return this.date;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setIp(java.lang.String ip) {
        this.ip = ip;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getIp() {
        return this.ip;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTvaLivraison(java.lang.Float tvaLivraison) {
        this.tvaLivraison = tvaLivraison;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getTvaLivraison() {
        return this.tvaLivraison;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setAdresseFact(Adresse adresseFact) {
        this.adresseFact = adresseFact;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Adresse getAdresseFact() {
        return this.adresseFact;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setAdresseLiv(Adresse adresseLiv) {
        this.adresseLiv = adresseLiv;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Adresse getAdresseLiv() {
        return this.adresseLiv;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setPaiement(Paiement paiement) {
        this.paiement = paiement;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Paiement getPaiement() {
        return this.paiement;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setTvaCommande(java.util.Collection<Tva> tvaCommande) {
        this.tvaCommande = tvaCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Tva> getTvaCommande() {
        return this.tvaCommande;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setDetailCommande(java.util.Collection<LigneCommande> detailCommande) {
        this.detailCommande = detailCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<LigneCommande> getDetailCommande() {
        return this.detailCommande;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListCommande(java.util.Collection<StatutCommande> ListCommande) {
        this.ListCommande = ListCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<StatutCommande> getListCommande() {
        return this.ListCommande;
    }
    
}

