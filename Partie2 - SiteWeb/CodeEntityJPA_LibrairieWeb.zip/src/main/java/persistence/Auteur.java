package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Auteur implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String nom;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String prenom;
    
    private java.lang.String pseudo;
    

    
    @javax.persistence.ManyToMany(
        mappedBy = "ListAuteur",
    	cascade = {javax.persistence.CascadeType.ALL}
    )
    java.util.Collection<Livre> ListLivre_Auteur;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNom(java.lang.String nom) {
        this.nom = nom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNom() {
        return this.nom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrenom(java.lang.String prenom) {
        this.prenom = prenom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getPrenom() {
        return this.prenom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPseudo(java.lang.String pseudo) {
        this.pseudo = pseudo;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getPseudo() {
        return this.pseudo;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListLivre_Auteur(java.util.Collection<Livre> ListLivre_Auteur) {
        this.ListLivre_Auteur = ListLivre_Auteur;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Livre> getListLivre_Auteur() {
        return this.ListLivre_Auteur;
    }
    
}

