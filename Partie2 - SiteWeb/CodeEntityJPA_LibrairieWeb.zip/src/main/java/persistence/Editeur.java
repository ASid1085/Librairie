package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Editeur implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = true, unique = false, updatable = true)
    private java.lang.String tel;
    
    private java.lang.String mail;
    
    private java.lang.String blabla;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "adresse_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "adr_auteur_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Adresse AdresseEditeur;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    java.util.Collection<Livre> ListLivre_editeur;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTel(java.lang.String tel) {
        this.tel = tel;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getTel() {
        return this.tel;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setMail(java.lang.String mail) {
        this.mail = mail;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getMail() {
        return this.mail;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setAdresseEditeur(Adresse AdresseEditeur) {
        this.AdresseEditeur = AdresseEditeur;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Adresse getAdresseEditeur() {
        return this.AdresseEditeur;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListLivre_editeur(java.util.Collection<Livre> ListLivre_editeur) {
        this.ListLivre_editeur = ListLivre_editeur;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Livre> getListLivre_editeur() {
        return this.ListLivre_editeur;
    }
    
}

