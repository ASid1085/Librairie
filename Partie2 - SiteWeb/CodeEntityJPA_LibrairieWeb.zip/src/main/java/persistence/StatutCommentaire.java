package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class StatutCommentaire implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.util.Date dateStatut;
    
    private java.lang.String blabla;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "statutComment_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "statutComment_Statuts_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Statuts statutCommentaire;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "ListCommentaire_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "statutCommetaire_commentaire_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Commentaire> ListCommentaire;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDateStatut(java.util.Date dateStatut) {
        this.dateStatut = dateStatut;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDateStatut() {
        return this.dateStatut;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setStatutCommentaire(Statuts statutCommentaire) {
        this.statutCommentaire = statutCommentaire;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Statuts getStatutCommentaire() {
        return this.statutCommentaire;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListCommentaire(java.util.Collection<Commentaire> ListCommentaire) {
        this.ListCommentaire = ListCommentaire;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Commentaire> getListCommentaire() {
        return this.ListCommentaire;
    }
    
}

