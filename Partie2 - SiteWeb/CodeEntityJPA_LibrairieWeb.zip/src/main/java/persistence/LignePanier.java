package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class LignePanier implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.Integer quantite;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.lang.Float prixHT;
    @javax.persistence.Column(insertable = true, length = 4, nullable = false, precision = 2, unique = false, updatable = true)
    private java.lang.Float tva;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "livreAjout_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "LigPanier_Livre_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Livre livreAjout;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setQuantite(java.lang.Integer quantite) {
        this.quantite = quantite;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getQuantite() {
        return this.quantite;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrixHT(java.lang.Float prixHT) {
        this.prixHT = prixHT;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getPrixHT() {
        return this.prixHT;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTva(java.lang.Float tva) {
        this.tva = tva;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Float getTva() {
        return this.tva;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setLivreAjout(Livre livreAjout) {
        this.livreAjout = livreAjout;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Livre getLivreAjout() {
        return this.livreAjout;
    }
    
}

