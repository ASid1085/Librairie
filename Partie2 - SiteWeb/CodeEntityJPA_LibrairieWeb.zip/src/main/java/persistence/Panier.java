package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Panier implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.util.Date date;
    

    
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "detailPanier_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "Panier_LigPanier_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<LignePanier> detailPanier;
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "panierDuClient_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "panier_client_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Client panierDuClient;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDate(java.util.Date date) {
        this.date = date;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDate() {
        return this.date;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setDetailPanier(java.util.Collection<LignePanier> detailPanier) {
        this.detailPanier = detailPanier;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<LignePanier> getDetailPanier() {
        return this.detailPanier;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setPanierDuClient(Client panierDuClient) {
        this.panierDuClient = panierDuClient;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Client getPanierDuClient() {
        return this.panierDuClient;
    }
    
}

