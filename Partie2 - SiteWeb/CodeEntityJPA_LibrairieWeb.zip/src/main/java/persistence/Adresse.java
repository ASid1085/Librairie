package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class Adresse implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Column(insertable = true, length = 10, nullable = false, unique = true, updatable = true)
    @javax.persistence.Id
    private java.lang.String ref;
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    @javax.persistence.GeneratedValue(strategy = javax.persistence.GenerationType.IDENTITY)
    private java.lang.Integer id;
    
    private java.lang.String libelle;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String nom;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String prenom;
    @javax.persistence.Column(insertable = true, length = 75, nullable = true, unique = false, updatable = true)
    private java.lang.String nomEntreprise;
    @javax.persistence.Column(insertable = true, length = 10, nullable = true, unique = false, updatable = true)
    private java.lang.String noRue;
    @javax.persistence.Column(insertable = true, length = 80, nullable = false, unique = false, updatable = true)
    private java.lang.String rue;
    
    private java.lang.String complement;
    @javax.persistence.Column(insertable = true, length = 20, nullable = false, unique = false, updatable = true)
    private java.lang.String cp;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String ville;
    @javax.persistence.Column(insertable = true, length = 75, nullable = false, unique = false, updatable = true)
    private java.lang.String pays;
    
    private java.lang.String tel;
    @javax.persistence.Column(insertable = true, length = 15, nullable = false, unique = false, updatable = true)
    private java.lang.String civilite;
    

    

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRef() {
        return this.ref;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setLibelle(java.lang.String libelle) {
        this.libelle = libelle;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getLibelle() {
        return this.libelle;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNom(java.lang.String nom) {
        this.nom = nom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNom() {
        return this.nom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPrenom(java.lang.String prenom) {
        this.prenom = prenom;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getPrenom() {
        return this.prenom;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNomEntreprise(java.lang.String nomEntreprise) {
        this.nomEntreprise = nomEntreprise;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNomEntreprise() {
        return this.nomEntreprise;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setNoRue(java.lang.String noRue) {
        this.noRue = noRue;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getNoRue() {
        return this.noRue;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setRue(java.lang.String rue) {
        this.rue = rue;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getRue() {
        return this.rue;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setComplement(java.lang.String complement) {
        this.complement = complement;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getComplement() {
        return this.complement;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setCp(java.lang.String cp) {
        this.cp = cp;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getCp() {
        return this.cp;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setVille(java.lang.String ville) {
        this.ville = ville;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getVille() {
        return this.ville;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setPays(java.lang.String pays) {
        this.pays = pays;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getPays() {
        return this.pays;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setTel(java.lang.String tel) {
        this.tel = tel;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getTel() {
        return this.tel;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setCivilite(java.lang.String civilite) {
        this.civilite = civilite;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getCivilite() {
        return this.civilite;
    }
    

    
}

