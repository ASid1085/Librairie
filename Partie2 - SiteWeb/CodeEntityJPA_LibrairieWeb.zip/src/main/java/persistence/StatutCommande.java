package persistence;


@javax.persistence.Entity
@javax.annotation.Generated("com.genmymodel.jpa")
public class StatutCommande implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    @javax.persistence.Id
    @javax.persistence.Column(insertable = true, nullable = false, unique = true, updatable = true)
    private java.lang.Integer id;
    @javax.persistence.Column(insertable = true, nullable = false, unique = false, updatable = true)
    private java.util.Date dateStatut;
    
    private java.lang.String blabla;
    

    
    @javax.persistence.OneToOne(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "statutCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "statutCommande_statuts_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    Statuts statutCommande;
    @javax.persistence.OneToMany(
        cascade = {javax.persistence.CascadeType.ALL}
    )
    @javax.persistence.JoinTable(
        joinColumns={@javax.persistence.JoinColumn(
    name = "ListStatutCommande_fk",
    unique = false,
    nullable = false,
    insertable = true,
    updatable = true, foreignKey=@javax.persistence.ForeignKey(name = "statutCommande_commande_fk", value = javax.persistence.ConstraintMode.CONSTRAINT)
    )
    }
    )
    java.util.Collection<Commande> ListStatutCommande;

    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setId(java.lang.Integer id) {
        this.id = id;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.Integer getId() {
        return this.id;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setDateStatut(java.util.Date dateStatut) {
        this.dateStatut = dateStatut;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Date getDateStatut() {
        return this.dateStatut;
    }
    @javax.annotation.Generated("genmymodel.jpa.generator")
    public void setBlabla(java.lang.String blabla) {
        this.blabla = blabla;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.lang.String getBlabla() {
        return this.blabla;
    }
    

    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setStatutCommande(Statuts statutCommande) {
        this.statutCommande = statutCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public Statuts getStatutCommande() {
        return this.statutCommande;
    }
    @javax.annotation.Generated("com.genmymodel.jpa")
    public void setListStatutCommande(java.util.Collection<Commande> ListStatutCommande) {
        this.ListStatutCommande = ListStatutCommande;
    }
    
    @javax.annotation.Generated("com.genmymodel.jpa")
    public java.util.Collection<Commande> getListStatutCommande() {
        return this.ListStatutCommande;
    }
    
}

